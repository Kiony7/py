c = 0
max = 3  # 最大转换次数

print(f"-----【您有{max}次转换机会】-----")

while c < max:
    c += 1
    m = int(input(f"【第 {c} 次。请输入分钟数: 】"))

    h = m // 60
    m = m % 60

    print(f"{h}小时 {m}分钟")

print("转换次数已达上限，程序退出。")
